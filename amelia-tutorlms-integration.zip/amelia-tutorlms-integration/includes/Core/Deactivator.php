<?php

namespace AmeliaTutor\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Deactivator {

    public static function deactivate() {
        // Intentionally empty
        // Do NOT delete data on deactivation
    }
}
