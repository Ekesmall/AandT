(function ($) {
    'use strict';

    // Future: service ↔ course ↔ lesson mapping UX

})(jQuery);
